import 'package:flutter/material.dart';
import '../providers/medicine_controller.dart';
import '../theme/app_theme.dart';
import 'schedule_screen.dart';
import 'medicines_screen.dart';
import 'history_screen.dart';

class HomeScreen extends StatefulWidget {
  final MedicineController controller;

  const HomeScreen({super.key, required this.controller});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.controller,
      builder: (context, _) {
        if (widget.controller.isLoading) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }

        final pages = [
          ScheduleScreen(controller: widget.controller),
          MedicinesScreen(controller: widget.controller),
          HistoryScreen(controller: widget.controller),
        ];

        return Scaffold(
          body: IndexedStack(
            index: _currentIndex,
            children: pages,
          ),
          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              border: Border(
                top: BorderSide(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? AppColors.darkBorder
                      : AppColors.lightBorder,
                  width: 1,
                ),
              ),
            ),
            child: NavigationBar(
              selectedIndex: _currentIndex,
              onDestinationSelected: (index) {
                setState(() {
                  _currentIndex = index;
                });
              },
              indicatorColor: AppColors.primaryLight,
              backgroundColor: Theme.of(context).brightness == Brightness.dark
                  ? AppColors.darkCard
                  : Colors.white,
              destinations: const [
                NavigationDestination(
                  icon: Icon(Icons.calendar_today_outlined),
                  selectedIcon: Icon(Icons.calendar_month_rounded, color: AppColors.primaryDark),
                  label: 'Today',
                ),
                NavigationDestination(
                  icon: Icon(Icons.medication_outlined),
                  selectedIcon: Icon(Icons.medication_rounded, color: AppColors.primaryDark),
                  label: 'Medicines',
                ),
                NavigationDestination(
                  icon: Icon(Icons.analytics_outlined),
                  selectedIcon: Icon(Icons.analytics_rounded, color: AppColors.primaryDark),
                  label: 'Adherence',
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
