import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../providers/medicine_controller.dart';
import '../theme/app_theme.dart';

class HistoryScreen extends StatelessWidget {
  final MedicineController controller;

  const HistoryScreen({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final now = DateTime.now();

    // Calculate last 7 days stats
    final last7Days = List.generate(7, (i) => now.subtract(Duration(days: 6 - i)));
    int totalScheduled7Days = 0;
    int totalTaken7Days = 0;

    for (final day in last7Days) {
      final stat = controller.getAdherenceForDate(day);
      totalScheduled7Days += stat.total;
      totalTaken7Days += stat.taken;
    }

    final weeklyAdherenceRate = totalScheduled7Days == 0
        ? 100
        : ((totalTaken7Days / totalScheduled7Days) * 100).round();

    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Adherence & History',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22),
            ),
            Text(
              'Track your health habits and medication streaks',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.normal, color: AppColors.lightSubtext),
            ),
          ],
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Weekly Overview Card
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: isDark
                    ? [const Color(0xFF1E293B), const Color(0xFF0F172A)]
                    : [const Color(0xFF0D9488), const Color(0xFF0284C7)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: AppColors.primary.withValues(alpha: 0.25),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(Icons.insights, color: Colors.white, size: 20),
                    SizedBox(width: 8),
                    Text(
                      '7-Day Adherence Rate',
                      style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      '$weeklyAdherenceRate%',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 36,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          '$totalTaken7Days of $totalScheduled7Days doses taken',
                          style: TextStyle(
                            color: Colors.white.withValues(alpha: 0.9),
                            fontSize: 13,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          weeklyAdherenceRate >= 80 ? '🌟 Great consistency!' : 'Keep building your routine!',
                          style: TextStyle(
                            color: Colors.white.withValues(alpha: 0.9),
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),

          const SizedBox(height: 24),

          // Last 7 Days Mini Breakdown
          const Text(
            'Daily Performance (Last 7 Days)',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),

          Card(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Column(
                children: last7Days.map((day) {
                  final stat = controller.getAdherenceForDate(day);
                  final isToday = DateUtils.isSameDay(day, now);
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Row(
                      children: [
                        SizedBox(
                          width: 80,
                          child: Text(
                            isToday ? 'Today' : DateFormat('EEE, d').format(day),
                            style: TextStyle(
                              fontWeight: isToday ? FontWeight.bold : FontWeight.w500,
                              color: isToday
                                  ? AppColors.primary
                                  : (isDark ? AppColors.darkText : AppColors.lightText),
                            ),
                          ),
                        ),
                        Expanded(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(6),
                            child: LinearProgressIndicator(
                              value: stat.total == 0 ? 0.0 : stat.ratio,
                              minHeight: 10,
                              backgroundColor: isDark ? Colors.white12 : const Color(0xFFF1F5F9),
                              valueColor: AlwaysStoppedAnimation<Color>(
                                stat.total == 0
                                    ? Colors.grey
                                    : (stat.percentage >= 80 ? AppColors.taken : AppColors.pending),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 14),
                        SizedBox(
                          width: 50,
                          child: Text(
                            stat.total == 0 ? '0/0' : '${stat.taken}/${stat.total}',
                            textAlign: TextAlign.end,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: isDark ? AppColors.darkSubtext : AppColors.lightSubtext,
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ),
            ),
          ),

          const SizedBox(height: 24),

          // Health Tip & Info Card
          Card(
            color: isDark ? const Color(0xFF1E293B) : const Color(0xFFF0FDF4),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
              side: BorderSide(
                color: isDark ? AppColors.darkBorder : const Color(0xFFBBF7D0),
              ),
            ),
            child: const Padding(
              padding: EdgeInsets.all(16),
              child: Row(
                children: [
                  Icon(Icons.tips_and_updates_outlined, color: AppColors.taken, size: 28),
                  SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Adherence Tip',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Taking medications at consistent times each day improves absorption and helps form a dependable habit.',
                          style: TextStyle(fontSize: 13, height: 1.3),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
