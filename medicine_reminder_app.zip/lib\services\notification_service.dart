import 'package:flutter/foundation.dart';
import '../models/medicine.dart';

class ScheduledNotification {
  final String id;
  final String medicineId;
  final String medicineName;
  final String dosage;
  final String reminderTime;
  final DateTime scheduledDateTime;

  ScheduledNotification({
    required this.id,
    required this.medicineId,
    required this.medicineName,
    required this.dosage,
    required this.reminderTime,
    required this.scheduledDateTime,
  });

  String get title => 'Reminder: $medicineName';
  String get body => 'Take $dosage at $reminderTime';

  Map<String, dynamic> toJson() => {
        'id': id,
        'medicineId': medicineId,
        'medicineName': medicineName,
        'dosage': dosage,
        'reminderTime': reminderTime,
        'scheduledDateTime': scheduledDateTime.toIso8601String(),
      };

  factory ScheduledNotification.fromJson(Map<String, dynamic> json) =>
      ScheduledNotification(
        id: json['id'] as String,
        medicineId: json['medicineId'] as String,
        medicineName: json['medicineName'] as String,
        dosage: json['dosage'] as String,
        reminderTime: json['reminderTime'] as String,
        scheduledDateTime: DateTime.parse(json['scheduledDateTime'] as String),
      );
}

class NotificationService extends ChangeNotifier {
  final Map<String, List<ScheduledNotification>> _scheduledByMedicine = {};

  NotificationService();

  List<ScheduledNotification> get allPendingNotifications {
    final list = <ScheduledNotification>[];
    for (final notifications in _scheduledByMedicine.values) {
      list.addAll(notifications);
    }
    list.sort((a, b) => a.scheduledDateTime.compareTo(b.scheduledDateTime));
    return list;
  }

  List<ScheduledNotification> getPendingForMedicine(String medicineId) {
    return List.unmodifiable(_scheduledByMedicine[medicineId] ?? []);
  }

  /// Schedules notifications for the next [daysAhead] days for an active medicine.
  void scheduleForMedicine(Medicine medicine, {int daysAhead = 30}) {
    // If medicine is inactive/stopped, ensure all notifications are cancelled
    if (!medicine.isActive) {
      cancelForMedicine(medicine.id);
      return;
    }

    final notifications = <ScheduledNotification>[];
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    for (int i = 0; i < daysAhead; i++) {
      final date = today.add(Duration(days: i));
      if (!medicine.isScheduledOn(date)) continue;

      for (final time in medicine.reminderTimes) {
        final timeParts = time.split(':').map(int.parse).toList();
        final scheduledDateTime = DateTime(
          date.year,
          date.month,
          date.day,
          timeParts[0],
          timeParts[1],
        );

        // Only schedule future or currently due notifications
        if (scheduledDateTime.isAfter(now.subtract(const Duration(minutes: 5)))) {
          final id = '${medicine.id}_${date.year}${date.month.toString().padLeft(2, '0')}${date.day.toString().padLeft(2, '0')}_$time';
          notifications.add(
            ScheduledNotification(
              id: id,
              medicineId: medicine.id,
              medicineName: medicine.name,
              dosage: medicine.dosage,
              reminderTime: time,
              scheduledDateTime: scheduledDateTime,
            ),
          );
        }
      }
    }

    _scheduledByMedicine[medicine.id] = notifications;
    notifyListeners();
  }

  /// Cancels all pending notifications for a medicine (e.g. when stopped or deleted).
  void cancelForMedicine(String medicineId) {
    if (_scheduledByMedicine.containsKey(medicineId)) {
      _scheduledByMedicine.remove(medicineId);
      notifyListeners();
    }
  }

  /// Updates notifications when a medicine schedule is edited.
  void updateForMedicine(Medicine medicine) {
    cancelForMedicine(medicine.id);
    if (medicine.isActive) {
      scheduleForMedicine(medicine);
    }
  }

  /// Adds a snoozed reminder notification after [minutes]
  void snoozeNotification({
    required Medicine medicine,
    required String reminderTime,
    int minutes = 10,
  }) {
    final snoozedTime = DateTime.now().add(Duration(minutes: minutes));
    final id = '${medicine.id}_snooze_${snoozedTime.millisecondsSinceEpoch}';

    final snoozeNotification = ScheduledNotification(
      id: id,
      medicineId: medicine.id,
      medicineName: medicine.name,
      dosage: medicine.dosage,
      reminderTime: reminderTime,
      scheduledDateTime: snoozedTime,
    );

    _scheduledByMedicine.putIfAbsent(medicine.id, () => []).add(snoozeNotification);
    notifyListeners();
  }

  /// Cancels all notifications across all medicines
  void cancelAll() {
    _scheduledByMedicine.clear();
    notifyListeners();
  }
}
