import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:medicine_reminder_app/models/medicine.dart';
import 'package:medicine_reminder_app/models/dose_record.dart';
import 'package:medicine_reminder_app/models/app_user.dart';
import 'package:medicine_reminder_app/services/storage_service.dart';
import 'package:medicine_reminder_app/providers/medicine_controller.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('Model Tests', () {
    test('Medicine model serializes and deserializes schedule types correctly', () {
      final now = DateTime(2026, 9, 21);
      final med = Medicine(
        id: 'test_weekly',
        name: 'Weekly Vitamin',
        dosage: '1000 IU',
        type: MedicineType.capsule,
        instruction: MealInstruction.withMeal,
        reminderTimes: ['09:00'],
        colorValue: 0xFF0D9488,
        startDate: now,
        scheduleType: ScheduleType.weekly,
        weeklyDays: [1, 4], // Mon and Thu
        monthlyDay: 15,
        customIntervalDays: 3,
      );

      final json = med.toJson();
      final fromJson = Medicine.fromJson(json);

      expect(fromJson.id, 'test_weekly');
      expect(fromJson.scheduleType, ScheduleType.weekly);
      expect(fromJson.weeklyDays, [1, 4]);
      expect(fromJson.monthlyDay, 15);
      expect(fromJson.customIntervalDays, 3);
    });

    test('DoseRecord serializes and deserializes snoozed status correctly', () {
      final now = DateTime(2026, 9, 21, 8, 0);
      final snoozedUntil = now.add(const Duration(minutes: 10));
      final record = DoseRecord(
        id: DoseRecord.generateId('med_1', '2026-09-21', '08:00'),
        medicineId: 'med_1',
        date: '2026-09-21',
        time: '08:00',
        status: DoseStatus.snoozed,
        snoozedUntil: snoozedUntil,
      );

      final json = record.toJson();
      final fromJson = DoseRecord.fromJson(json);

      expect(fromJson.status, DoseStatus.snoozed);
      expect(fromJson.snoozedUntil, snoozedUntil);
    });

    test('AppUser model serializes and deserializes correctly', () {
      final user = AppUser(name: 'Sarah Smith', email: 'sarah@example.com');
      final json = user.toJson();
      final fromJson = AppUser.fromJson(json);

      expect(fromJson.name, 'Sarah Smith');
      expect(fromJson.email, 'sarah@example.com');
    });
  });

  group('Scheduling Logic Tests (Weekly, Monthly, Custom Interval)', () {
    test('Weekly schedule matches only selected days of the week', () {
      final start = DateTime(2026, 1, 1);
      final weeklyMed = Medicine(
        id: 'med_weekly',
        name: 'Weekly Pill',
        dosage: '1 pill',
        type: MedicineType.tablet,
        instruction: MealInstruction.afterMeal,
        reminderTimes: ['08:00'],
        colorValue: 0xFF00897B,
        startDate: start,
        scheduleType: ScheduleType.weekly,
        weeklyDays: [DateTime.monday, DateTime.thursday], // Monday and Thursday
      );

      // 2026-10-05 is a Monday
      expect(weeklyMed.isScheduledOn(DateTime(2026, 10, 5)), true);
      // 2026-10-06 is a Tuesday
      expect(weeklyMed.isScheduledOn(DateTime(2026, 10, 6)), false);
      // 2026-10-07 is a Wednesday
      expect(weeklyMed.isScheduledOn(DateTime(2026, 10, 7)), false);
      // 2026-10-08 is a Thursday
      expect(weeklyMed.isScheduledOn(DateTime(2026, 10, 8)), true);
      // 2026-10-09 is a Friday
      expect(weeklyMed.isScheduledOn(DateTime(2026, 10, 9)), false);
    });

    test('Monthly schedule handles shorter months correctly (day 31 rule)', () {
      final start = DateTime(2024, 1, 1);
      final monthlyMed = Medicine(
        id: 'med_monthly_31',
        name: 'Monthly Injection',
        dosage: '1 vial',
        type: MedicineType.injection,
        instruction: MealInstruction.anytime,
        reminderTimes: ['10:00'],
        colorValue: 0xFF00897B,
        startDate: start,
        scheduleType: ScheduleType.monthly,
        monthlyDay: 31,
      );

      // In January (31 days): triggers on 31st, not 30th
      expect(monthlyMed.isScheduledOn(DateTime(2025, 1, 31)), true);
      expect(monthlyMed.isScheduledOn(DateTime(2025, 1, 30)), false);

      // In February (non-leap year, 28 days): triggers on Feb 28th
      expect(monthlyMed.isScheduledOn(DateTime(2025, 2, 28)), true);
      expect(monthlyMed.isScheduledOn(DateTime(2025, 2, 27)), false);

      // In February (leap year, 2024 has 29 days): triggers on Feb 29th
      expect(monthlyMed.isScheduledOn(DateTime(2024, 2, 29)), true);
      expect(monthlyMed.isScheduledOn(DateTime(2024, 2, 28)), false);

      // In April (30 days): triggers on April 30th
      expect(monthlyMed.isScheduledOn(DateTime(2025, 4, 30)), true);
      expect(monthlyMed.isScheduledOn(DateTime(2025, 4, 29)), false);
    });

    test('Custom interval schedule triggers on exact step days', () {
      final start = DateTime(2026, 9, 20);
      final intervalMed = Medicine(
        id: 'med_interval',
        name: 'Every 3 Days',
        dosage: '1 tab',
        type: MedicineType.tablet,
        instruction: MealInstruction.withMeal,
        reminderTimes: ['12:00'],
        colorValue: 0xFF00897B,
        startDate: start,
        scheduleType: ScheduleType.customInterval,
        customIntervalDays: 3,
      );

      expect(intervalMed.isScheduledOn(DateTime(2026, 9, 20)), true); // Day 0
      expect(intervalMed.isScheduledOn(DateTime(2026, 9, 21)), false); // Day 1
      expect(intervalMed.isScheduledOn(DateTime(2026, 9, 22)), false); // Day 2
      expect(intervalMed.isScheduledOn(DateTime(2026, 9, 23)), true); // Day 3
      expect(intervalMed.isScheduledOn(DateTime(2026, 9, 24)), false); // Day 4
      expect(intervalMed.isScheduledOn(DateTime(2026, 9, 26)), true); // Day 6
    });
  });

  group('Authentication Tests', () {
    late StorageService storageService;
    late MedicineController controller;

    setUp(() async {
      SharedPreferences.setMockInitialValues({});
      storageService = await StorageService.init();
      controller = MedicineController(storageService);
      await controller.loadData();
    });

    test('Initial auth state is unauthenticated', () {
      expect(controller.isAuthenticated, false);
      expect(controller.currentUser, null);
    });

    test('Can log in using Quick Demo User', () async {
      await controller.loginAsDemoUser();
      expect(controller.isAuthenticated, true);
      expect(controller.currentUser?.email, 'demo@health.com');
      expect(controller.currentUser?.name, 'Alex Johnson');
    });

    test('Can register a new user and login', () async {
      final registered = await controller.register('John Doe', 'john@example.com', 'password123');
      expect(registered, true);
      expect(controller.isAuthenticated, true);
      expect(controller.currentUser?.name, 'John Doe');
      expect(controller.currentUser?.email, 'john@example.com');

      // Logout
      await controller.logout();
      expect(controller.isAuthenticated, false);

      // Re-login with registered credentials
      final loggedIn = await controller.login('john@example.com', 'password123');
      expect(loggedIn, true);
      expect(controller.isAuthenticated, true);
    });
  });

  group('MedicineController State & Notification Tests', () {
    late StorageService storageService;
    late MedicineController controller;

    setUp(() async {
      SharedPreferences.setMockInitialValues({});
      storageService = await StorageService.init();
      controller = MedicineController(storageService);
      await controller.loadData();
    });

    test('Schedules doses and marks them as taken, skipped, or snoozed', () async {
      final testDate = DateTime(2026, 9, 21);
      final testMed = Medicine(
        id: 'med_test',
        name: 'Test Med',
        dosage: '1 pill',
        type: MedicineType.capsule,
        instruction: MealInstruction.beforeMeal,
        reminderTimes: ['09:00', '18:00'],
        colorValue: 0xFF10B981,
        startDate: testDate,
        stockCount: 15,
      );

      await controller.addMedicine(testMed);

      final dateKey = MedicineController.formatDate(testDate);
      final doses = controller.getDosesForDate(testDate);
      expect(doses.any((d) => d.medicine.id == 'med_test' && d.time == '09:00'), true);

      // Snooze dose
      await controller.snoozeDose(
        medicineId: 'med_test',
        date: dateKey,
        time: '09:00',
        minutes: 15,
      );

      final snoozedDoses = controller.getDosesForDate(testDate);
      final snoozedDose = snoozedDoses.firstWhere((d) => d.medicine.id == 'med_test' && d.time == '09:00');
      expect(snoozedDose.status, DoseStatus.snoozed);
      expect(snoozedDose.record?.snoozedUntil != null, true);

      // Mark morning dose as taken
      await controller.markDoseTaken(
        medicineId: 'med_test',
        date: dateKey,
        time: '09:00',
      );

      final updatedDoses = controller.getDosesForDate(testDate);
      final takenDose = updatedDoses.firstWhere((d) => d.medicine.id == 'med_test' && d.time == '09:00');
      expect(takenDose.status, DoseStatus.taken);
      expect(controller.getMedicineById('med_test')?.stockCount, 14);
    });

    test('Stopping/pausing a schedule cancels notifications and removes daily doses', () async {
      final testDate = DateTime(2026, 9, 21);
      final testMed = Medicine(
        id: 'med_stoppable',
        name: 'Daily Vitamin',
        dosage: '1 tablet',
        type: MedicineType.tablet,
        instruction: MealInstruction.afterMeal,
        reminderTimes: ['08:00'],
        colorValue: 0xFF0D9488,
        startDate: testDate,
        isActive: true,
      );

      await controller.addMedicine(testMed);

      // Verify active notifications and doses exist
      expect(controller.notificationService.getPendingForMedicine('med_stoppable').isNotEmpty, true);
      expect(controller.getDosesForDate(testDate).any((d) => d.medicine.id == 'med_stoppable'), true);

      // Pause/Stop the schedule
      await controller.toggleMedicineActive('med_stoppable');

      // Notifications should be cancelled and doses should not appear
      expect(controller.getMedicineById('med_stoppable')?.isActive, false);
      expect(controller.notificationService.getPendingForMedicine('med_stoppable').isEmpty, true);
      expect(controller.getDosesForDate(testDate).any((d) => d.medicine.id == 'med_stoppable'), false);

      // Resume schedule
      await controller.toggleMedicineActive('med_stoppable');
      expect(controller.getMedicineById('med_stoppable')?.isActive, true);
      expect(controller.notificationService.getPendingForMedicine('med_stoppable').isNotEmpty, true);
    });
  });
}
