import 'package:flutter/material.dart';
import 'providers/medicine_controller.dart';
import 'services/storage_service.dart';
import 'theme/app_theme.dart';
import 'screens/home_screen.dart';
import 'screens/login_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final storageService = await StorageService.init();
  final medicineController = MedicineController(storageService);

  runApp(MedicineReminderApp(controller: medicineController));
}

class MedicineReminderApp extends StatelessWidget {
  final MedicineController controller;

  const MedicineReminderApp({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: controller,
      builder: (context, _) {
        return MaterialApp(
          title: 'Medicine Reminder',
          debugShowCheckedModeBanner: false,
          theme: AppTheme.lightTheme,
          darkTheme: AppTheme.darkTheme,
          themeMode: ThemeMode.system,
          home: controller.isLoading
              ? const Scaffold(
                  body: Center(
                    child: CircularProgressIndicator(),
                  ),
                )
              : (controller.isAuthenticated
                  ? HomeScreen(controller: controller)
                  : LoginScreen(controller: controller)),
        );
      },
    );
  }
}
