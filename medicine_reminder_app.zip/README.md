# Medicine Reminder App

A complete, modern cross-platform Flutter application for managing medications, configuring custom reminder schedules, and tracking daily doses with adherence statistics.

---

## 📱 Features

- **Daily Schedule & Timeline**: Browse daily schedules with a horizontal date picker, grouped by time of day (Morning, Afternoon, Evening, Night).
- **Interactive Intake Actions**: One-tap "Take Dose", "Skip", or "Undo" with instant feedback.
- **Adherence & Progress**: Live daily progress ring and 7-day adherence history.
- **Active Reminder Alert**: High-visibility banner for due/overdue medications.
- **Medicine Catalog**: Search, filter by active or low-stock, view details, edit, or remove.
- **Add / Edit Medication**:
  - Name with quick-suggestion chips
  - Dosage and units (mg, ml, tablet, etc.)
  - Form selector (Tablet, Capsule, Syrup, Injection, Drops, Inhaler, Ointment)
  - Food timing instructions (Before meal, After meal, With meal, Empty stomach, Anytime)
  - Multi-time daily reminder picker with Flutter TimePicker
  - Pill stock counter with low-stock alerts
  - 8-color preset tags
  - Doctor's advice & notes
- **Local Persistence**: All medicines and dose history are saved locally using `shared_preferences`.

---

## 🚀 How to Run

### Prerequisites
- [Flutter SDK](https://docs.flutter.dev/get-started/install) installed.

### 1. Launch in Web Browser (Chrome / Edge)
```bash
flutter run -d chrome
```

### 2. Launch on Android (Emulator or Connected Phone)
```bash
flutter run -d android
```

### 3. Build an Android APK
```bash
flutter build apk --release
```
The resulting APK will be saved at `build/app/outputs/flutter-apk/app-release.apk`.

### 4. Run Automated Tests
```bash
flutter test
```
