import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/medicine.dart';
import '../providers/medicine_controller.dart';
import '../theme/app_theme.dart';

class AddEditMedicineScreen extends StatefulWidget {
  final MedicineController controller;
  final Medicine? medicineToEdit;

  const AddEditMedicineScreen({
    super.key,
    required this.controller,
    this.medicineToEdit,
  });

  @override
  State<AddEditMedicineScreen> createState() => _AddEditMedicineScreenState();
}

class _AddEditMedicineScreenState extends State<AddEditMedicineScreen> {
  final _formKey = GlobalKey<FormState>();

  late TextEditingController _nameController;
  late TextEditingController _dosageController;
  late TextEditingController _stockController;
  late TextEditingController _notesController;
  late TextEditingController _customIntervalController;

  late MedicineType _selectedType;
  late MealInstruction _selectedInstruction;
  late List<String> _reminderTimes;
  late int _selectedColor;

  // Schedule Fields
  late ScheduleType _selectedScheduleType;
  late List<int> _selectedWeeklyDays; // 1 = Mon, 7 = Sun
  late int _selectedMonthlyDay; // 1 to 31
  late DateTime _startDate;
  late DateTime? _endDate;

  static const List<String> _quickSuggestions = [
    'Paracetamol',
    'Amoxicillin',
    'Metformin',
    'Ibuprofen',
    'Vitamin D3',
    'Omeprazole',
    'Lisinopril',
    'Cetirizine',
  ];

  static const Map<int, String> _weekdayLabels = {
    1: 'Mon',
    2: 'Tue',
    3: 'Wed',
    4: 'Thu',
    5: 'Fri',
    6: 'Sat',
    7: 'Sun',
  };

  @override
  void initState() {
    super.initState();
    final med = widget.medicineToEdit;
    _nameController = TextEditingController(text: med?.name ?? '');
    _dosageController = TextEditingController(text: med?.dosage ?? '');
    _stockController = TextEditingController(text: med?.stockCount?.toString() ?? '');
    _notesController = TextEditingController(text: med?.notes ?? '');

    _selectedType = med?.type ?? MedicineType.tablet;
    _selectedInstruction = med?.instruction ?? MealInstruction.afterMeal;
    _reminderTimes = med != null ? List<String>.from(med.reminderTimes) : ['08:00', '20:00'];
    _selectedColor = med?.colorValue ?? AppColors.presetColors[0];

    // Initialize Schedule State
    _selectedScheduleType = med?.scheduleType ?? ScheduleType.daily;
    _selectedWeeklyDays = med != null ? List<int>.from(med.weeklyDays) : [1, 2, 3, 4, 5, 6, 7];
    _selectedMonthlyDay = med?.monthlyDay ?? 1;
    _customIntervalController = TextEditingController(
      text: (med?.customIntervalDays ?? 2).toString(),
    );
    _startDate = med?.startDate ?? DateTime.now();
    _endDate = med?.endDate;
  }

  @override
  void dispose() {
    _nameController.dispose();
    _dosageController.dispose();
    _stockController.dispose();
    _notesController.dispose();
    _customIntervalController.dispose();
    super.dispose();
  }

  String _formatTime12Hour(String time24) {
    try {
      final parts = time24.split(':');
      final hour = int.parse(parts[0]);
      final minute = int.parse(parts[1]);
      final dt = DateTime(2026, 1, 1, hour, minute);
      return DateFormat('h:mm a').format(dt);
    } catch (_) {
      return time24;
    }
  }

  Future<void> _pickTime() async {
    final now = TimeOfDay.now();
    final picked = await showTimePicker(
      context: context,
      initialTime: now,
    );

    if (picked != null) {
      final timeStr = "${picked.hour.toString().padLeft(2, '0')}:${picked.minute.toString().padLeft(2, '0')}";
      if (!_reminderTimes.contains(timeStr)) {
        setState(() {
          _reminderTimes.add(timeStr);
          _reminderTimes.sort();
        });
      }
    }
  }

  Future<void> _pickStartDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _startDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2035),
    );
    if (picked != null) {
      setState(() {
        _startDate = picked;
        if (_endDate != null && _endDate!.isBefore(_startDate)) {
          _endDate = null;
        }
      });
    }
  }

  Future<void> _pickEndDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _endDate ?? _startDate.add(const Duration(days: 30)),
      firstDate: _startDate,
      lastDate: DateTime(2035),
    );
    if (picked != null) {
      setState(() {
        _endDate = picked;
      });
    }
  }

  Future<void> _saveMedicine() async {
    if (!_formKey.currentState!.validate()) return;

    if (_reminderTimes.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please add at least one reminder time.'),
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    if (_selectedScheduleType == ScheduleType.weekly && _selectedWeeklyDays.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select at least one day of the week.'),
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    final stock = int.tryParse(_stockController.text.trim());
    final interval = int.tryParse(_customIntervalController.text.trim()) ?? 1;
    final isEditing = widget.medicineToEdit != null;

    final medicine = Medicine(
      id: widget.medicineToEdit?.id ?? 'med_${DateTime.now().millisecondsSinceEpoch}',
      name: _nameController.text.trim(),
      dosage: _dosageController.text.trim(),
      type: _selectedType,
      instruction: _selectedInstruction,
      reminderTimes: _reminderTimes,
      colorValue: _selectedColor,
      startDate: _startDate,
      endDate: _endDate,
      stockCount: stock,
      notes: _notesController.text.trim().isEmpty ? null : _notesController.text.trim(),
      isActive: widget.medicineToEdit?.isActive ?? true,
      scheduleType: _selectedScheduleType,
      weeklyDays: _selectedWeeklyDays,
      monthlyDay: _selectedMonthlyDay,
      customIntervalDays: interval > 0 ? interval : 1,
    );

    if (isEditing) {
      await widget.controller.updateMedicine(medicine);
    } else {
      await widget.controller.addMedicine(medicine);
    }

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(isEditing
              ? 'Schedule & reminders updated successfully!'
              : 'Medicine scheduled with reminders!'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: AppColors.taken,
        ),
      );
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isEditing = widget.medicineToEdit != null;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          isEditing ? 'Edit Medicine Schedule' : 'Add New Medicine',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            // Healthcare Guidance Note
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: isDark ? const Color(0xFF1E293B) : const Color(0xFFF0FDF4),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isDark ? AppColors.darkBorder : const Color(0xFFBBF7D0),
                ),
              ),
              child: const Row(
                children: [
                  Icon(Icons.verified_user_outlined, size: 20, color: AppColors.taken),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Please enter the exact dosage and schedule prescribed by your healthcare provider.',
                      style: TextStyle(fontSize: 12, height: 1.3),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Medicine Name Input
            const Text(
              'Medicine Name',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
            ),
            const SizedBox(height: 8),
            TextFormField(
              controller: _nameController,
              decoration: const InputDecoration(
                hintText: 'e.g. Amoxicillin, Paracetamol',
                prefixIcon: Icon(Icons.medication_outlined),
              ),
              validator: (val) {
                if (val == null || val.trim().isEmpty) {
                  return 'Please enter medicine name';
                }
                return null;
              },
            ),

            // Quick Name Suggestions
            const SizedBox(height: 8),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: _quickSuggestions.map((suggestion) {
                  return Padding(
                    padding: const EdgeInsets.only(right: 6),
                    child: ActionChip(
                      label: Text(suggestion, style: const TextStyle(fontSize: 12)),
                      onPressed: () {
                        setState(() {
                          _nameController.text = suggestion;
                        });
                      },
                    ),
                  );
                }).toList(),
              ),
            ),

            const SizedBox(height: 20),

            // Dosage Input (User enters prescribed dose)
            const Text(
              'Prescribed Dose / Strength',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
            ),
            const SizedBox(height: 8),
            TextFormField(
              controller: _dosageController,
              decoration: const InputDecoration(
                hintText: 'e.g. 500 mg, 1 tablet, 10 ml, 2 puffs',
                prefixIcon: Icon(Icons.scale_outlined),
              ),
              validator: (val) {
                if (val == null || val.trim().isEmpty) {
                  return 'Please enter prescribed dosage';
                }
                return null;
              },
            ),

            const SizedBox(height: 20),

            // Schedule Type Selector
            const Text(
              'Schedule Frequency',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
            ),
            const SizedBox(height: 8),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: ScheduleType.values.map((st) {
                  final isSelected = _selectedScheduleType == st;
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      avatar: Icon(
                        st.icon,
                        size: 16,
                        color: isSelected ? Colors.white : AppColors.primary,
                      ),
                      label: Text(st.displayName),
                      selected: isSelected,
                      selectedColor: AppColors.primary,
                      labelStyle: TextStyle(
                        color: isSelected ? Colors.white : (isDark ? AppColors.darkText : AppColors.lightText),
                        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                      ),
                      onSelected: (selected) {
                        if (selected) {
                          setState(() {
                            _selectedScheduleType = st;
                          });
                        }
                      },
                    ),
                  );
                }).toList(),
              ),
            ),

            const SizedBox(height: 16),

            // Weekly Days Selection
            if (_selectedScheduleType == ScheduleType.weekly) ...[
              const Text(
                'Select Days of the Week',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: _weekdayLabels.entries.map((entry) {
                  final dayIndex = entry.key;
                  final dayName = entry.value;
                  final isDaySelected = _selectedWeeklyDays.contains(dayIndex);
                  return FilterChip(
                    label: Text(dayName),
                    selected: isDaySelected,
                    selectedColor: AppColors.primaryLight,
                    checkmarkColor: AppColors.primary,
                    labelStyle: TextStyle(
                      color: isDaySelected ? AppColors.primaryDark : (isDark ? AppColors.darkText : AppColors.lightText),
                      fontWeight: isDaySelected ? FontWeight.bold : FontWeight.normal,
                    ),
                    onSelected: (selected) {
                      setState(() {
                        if (selected) {
                          _selectedWeeklyDays.add(dayIndex);
                          _selectedWeeklyDays.sort();
                        } else {
                          _selectedWeeklyDays.remove(dayIndex);
                        }
                      });
                    },
                  );
                }).toList(),
              ),
              const SizedBox(height: 16),
            ],

            // Monthly Day Selection with shorter month notice
            if (_selectedScheduleType == ScheduleType.monthly) ...[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Day of Month',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.primaryLight,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      'Day $_selectedMonthlyDay',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        color: AppColors.primaryDark,
                      ),
                    ),
                  ),
                ],
              ),
              Slider(
                value: _selectedMonthlyDay.toDouble(),
                min: 1,
                max: 31,
                divisions: 30,
                label: 'Day $_selectedMonthlyDay',
                activeColor: AppColors.primary,
                onChanged: (val) {
                  setState(() {
                    _selectedMonthlyDay = val.round();
                  });
                },
              ),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: isDark ? const Color(0xFF1E293B) : const Color(0xFFFEF3C7),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: isDark ? AppColors.darkBorder : const Color(0xFFFDE68A),
                  ),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.info_outline, size: 18, color: Color(0xFFD97706)),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        _selectedMonthlyDay >= 29
                            ? 'Months with fewer than $_selectedMonthlyDay days (such as February, April, June, Sept, Nov) will remind on the last day of that month.'
                            : 'Reminders will trigger on the ${_selectedMonthlyDay}th of each month.',
                        style: const TextStyle(fontSize: 12, height: 1.3),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
            ],

            // Custom Interval
            if (_selectedScheduleType == ScheduleType.customInterval) ...[
              const Text(
                'Repeat Interval (in days)',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _customIntervalController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  hintText: 'e.g. 2 for every other day, 3 for every 3 days',
                  prefixIcon: Icon(Icons.repeat),
                ),
              ),
              const SizedBox(height: 16),
            ],

            // Start Date & Optional End Date
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Start Date',
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                      ),
                      const SizedBox(height: 6),
                      OutlinedButton.icon(
                        onPressed: _pickStartDate,
                        icon: const Icon(Icons.calendar_today, size: 16),
                        label: Text(
                          DateFormat('MMM d, yyyy').format(_startDate),
                          style: const TextStyle(fontSize: 12),
                        ),
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'End Date',
                            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                          ),
                          if (_endDate != null)
                            GestureDetector(
                              onTap: () => setState(() => _endDate = null),
                              child: const Text('Clear', style: TextStyle(fontSize: 11, color: Colors.red)),
                            ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      OutlinedButton.icon(
                        onPressed: _pickEndDate,
                        icon: const Icon(Icons.event_busy, size: 16),
                        label: Text(
                          _endDate != null ? DateFormat('MMM d, yyyy').format(_endDate!) : 'Ongoing',
                          style: const TextStyle(fontSize: 12),
                        ),
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),

            // Medicine Form / Type
            const Text(
              'Medicine Form',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
            ),
            const SizedBox(height: 8),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: MedicineType.values.map((type) {
                  final isSelected = _selectedType == type;
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      avatar: Icon(
                        type.icon,
                        size: 16,
                        color: isSelected ? Colors.white : AppColors.primary,
                      ),
                      label: Text(type.displayName),
                      selected: isSelected,
                      selectedColor: AppColors.primary,
                      labelStyle: TextStyle(
                        color: isSelected ? Colors.white : (isDark ? AppColors.darkText : AppColors.lightText),
                        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                      ),
                      onSelected: (selected) {
                        if (selected) {
                          setState(() {
                            _selectedType = type;
                          });
                        }
                      },
                    ),
                  );
                }).toList(),
              ),
            ),

            const SizedBox(height: 20),

            // Meal Instructions
            const Text(
              'Meal Instructions',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: MealInstruction.values.map((instruction) {
                final isSelected = _selectedInstruction == instruction;
                return ChoiceChip(
                  avatar: Icon(
                    instruction.icon,
                    size: 16,
                    color: isSelected ? Colors.white : AppColors.primary,
                  ),
                  label: Text(instruction.displayName),
                  selected: isSelected,
                  selectedColor: AppColors.primary,
                  labelStyle: TextStyle(
                    color: isSelected ? Colors.white : (isDark ? AppColors.darkText : AppColors.lightText),
                    fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                  ),
                  onSelected: (selected) {
                    if (selected) {
                      setState(() {
                        _selectedInstruction = instruction;
                      });
                    }
                  },
                );
              }).toList(),
            ),

            const SizedBox(height: 24),

            // Reminder Times Section
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Reminder Times',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                ),
                TextButton.icon(
                  onPressed: _pickTime,
                  icon: const Icon(Icons.add_alarm, size: 18),
                  label: const Text('Add Time'),
                  style: TextButton.styleFrom(
                    foregroundColor: AppColors.primary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),

            if (_reminderTimes.isEmpty)
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: isDark ? AppColors.darkCard : Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.red.withValues(alpha: 0.5)),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.warning_amber_rounded, color: Colors.red, size: 20),
                    SizedBox(width: 8),
                    Text('No reminder time set. Tap "+ Add Time" above.'),
                  ],
                ),
              )
            else
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: _reminderTimes.map((time) {
                  return Chip(
                    backgroundColor: Color(_selectedColor).withValues(alpha: 0.12),
                    side: BorderSide(color: Color(_selectedColor).withValues(alpha: 0.4)),
                    avatar: Icon(Icons.alarm, size: 16, color: Color(_selectedColor)),
                    label: Text(
                      _formatTime12Hour(time),
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Color(_selectedColor),
                      ),
                    ),
                    deleteIcon: const Icon(Icons.close, size: 16),
                    deleteIconColor: Color(_selectedColor),
                    onDeleted: () {
                      setState(() {
                        _reminderTimes.remove(time);
                      });
                    },
                  );
                }).toList(),
              ),

            const SizedBox(height: 24),

            // Color Selector
            const Text(
              'Color Tag',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
            ),
            const SizedBox(height: 8),
            Row(
              children: AppColors.presetColors.map((colorVal) {
                final isSelected = _selectedColor == colorVal;
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      _selectedColor = colorVal;
                    });
                  },
                  child: Container(
                    margin: const EdgeInsets.only(right: 12),
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: Color(colorVal),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: isSelected ? Colors.white : Colors.transparent,
                        width: 3,
                      ),
                      boxShadow: isSelected
                          ? [
                              BoxShadow(
                                color: Color(colorVal).withValues(alpha: 0.5),
                                blurRadius: 8,
                                spreadRadius: 2,
                              )
                            ]
                          : null,
                    ),
                    child: isSelected
                        ? const Icon(Icons.check, color: Colors.white, size: 20)
                        : null,
                  ),
                );
              }).toList(),
            ),

            const SizedBox(height: 24),

            // Stock Count (Optional)
            const Text(
              'Pills in Stock (Optional)',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
            ),
            const SizedBox(height: 8),
            TextFormField(
              controller: _stockController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                hintText: 'e.g. 30',
                prefixIcon: Icon(Icons.inventory_2_outlined),
              ),
            ),

            const SizedBox(height: 20),

            // Doctor's Instructions / Notes
            const Text(
              'Doctor Notes & Directions (Optional)',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
            ),
            const SizedBox(height: 8),
            TextFormField(
              controller: _notesController,
              maxLines: 3,
              decoration: const InputDecoration(
                hintText: 'e.g. Prescribed by Dr. Smith. Take with plenty of water.',
                alignLabelWithHint: true,
              ),
            ),

            const SizedBox(height: 32),

            // Save Button
            FilledButton.icon(
              onPressed: _saveMedicine,
              icon: const Icon(Icons.save_rounded),
              label: Text(
                isEditing ? 'Update Medicine Schedule' : 'Save Medicine & Set Reminders',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              style: FilledButton.styleFrom(
                backgroundColor: AppColors.primary,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
            ),

            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}
