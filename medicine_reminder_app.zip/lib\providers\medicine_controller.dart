import 'package:flutter/material.dart';
import '../models/medicine.dart';
import '../models/dose_record.dart';
import '../models/app_user.dart';
import '../services/storage_service.dart';
import '../services/notification_service.dart';

class ScheduledDoseItem {
  final Medicine medicine;
  final String time; // "HH:mm"
  final String date; // "YYYY-MM-DD"
  final DoseRecord? record;

  ScheduledDoseItem({
    required this.medicine,
    required this.time,
    required this.date,
    this.record,
  });

  DoseStatus get status => record?.status ?? DoseStatus.pending;

  DateTime get scheduledDateTime {
    final parts = date.split('-').map(int.parse).toList();
    final timeParts = time.split(':').map(int.parse).toList();
    return DateTime(parts[0], parts[1], parts[2], timeParts[0], timeParts[1]);
  }

  bool get isOverdue {
    if (status != DoseStatus.pending) return false;
    return scheduledDateTime.isBefore(DateTime.now());
  }

  String get timeSlot {
    final hour = int.tryParse(time.split(':').first) ?? 12;
    if (hour >= 5 && hour < 12) return 'Morning';
    if (hour >= 12 && hour < 17) return 'Afternoon';
    if (hour >= 17 && hour < 21) return 'Evening';
    return 'Night';
  }
}

class AdherenceStats {
  final int total;
  final int taken;
  final int skipped;
  final int pending;

  AdherenceStats({
    required this.total,
    required this.taken,
    required this.skipped,
    required this.pending,
  });

  double get ratio => total == 0 ? 1.0 : (taken / total);
  int get percentage => (ratio * 100).round();
}

class MedicineController extends ChangeNotifier {
  final StorageService _storageService;
  final NotificationService notificationService;

  List<Medicine> _medicines = [];
  Map<String, DoseRecord> _doseRecords = {};
  DateTime _selectedDate = DateTime.now();
  bool _isLoading = true;
  AppUser? _currentUser;

  MedicineController(
    this._storageService, {
    NotificationService? notificationService,
  }) : notificationService = notificationService ?? NotificationService() {
    loadData();
  }

  List<Medicine> get medicines => List.unmodifiable(_medicines);
  DateTime get selectedDate => _selectedDate;
  bool get isLoading => _isLoading;
  AppUser? get currentUser => _currentUser;
  bool get isAuthenticated => _currentUser != null;

  static String formatDate(DateTime dt) {
    return "${dt.year}-${dt.month.toString().padLeft(2, '0')}-${dt.day.toString().padLeft(2, '0')}";
  }

  Future<void> loadData() async {
    _isLoading = true;
    notifyListeners();

    _currentUser = await _storageService.loadCurrentUser();
    _medicines = await _storageService.loadMedicines();
    final records = await _storageService.loadDoseRecords();
    _doseRecords = {for (var r in records) r.id: r};

    // Initialize notification schedules for all active medicines
    for (final med in _medicines) {
      if (med.isActive) {
        notificationService.scheduleForMedicine(med);
      }
    }

    _isLoading = false;
    notifyListeners();
  }

  Future<bool> login(String email, String password) async {
    final user = _storageService.authenticate(email, password);
    if (user != null) {
      _currentUser = user;
      await _storageService.saveCurrentUser(user);
      notifyListeners();
      return true;
    }
    return false;
  }

  Future<bool> register(String name, String email, String password) async {
    if (_storageService.isEmailRegistered(email)) {
      return false;
    }
    await _storageService.registerUser(
      name: name,
      email: email,
      password: password,
    );
    final user = AppUser(name: name, email: email);
    _currentUser = user;
    await _storageService.saveCurrentUser(user);
    notifyListeners();
    return true;
  }

  Future<void> loginAsDemoUser() async {
    final user = AppUser(name: 'Alex Johnson', email: 'demo@health.com');
    _currentUser = user;
    await _storageService.saveCurrentUser(user);
    notifyListeners();
  }

  Future<void> logout() async {
    _currentUser = null;
    await _storageService.clearCurrentUser();
    notifyListeners();
  }

  void selectDate(DateTime date) {
    _selectedDate = DateTime(date.year, date.month, date.day);
    notifyListeners();
  }

  List<ScheduledDoseItem> getDosesForDate(DateTime date) {
    final dateKey = formatDate(date);
    final targetDate = DateTime(date.year, date.month, date.day);
    final items = <ScheduledDoseItem>[];

    for (final med in _medicines) {
      // Uses the schedule logic (Daily, Weekly, Monthly with shorter month rule, Custom Interval)
      if (!med.isScheduledOn(targetDate)) continue;

      for (final time in med.reminderTimes) {
        final recordId = DoseRecord.generateId(med.id, dateKey, time);
        final record = _doseRecords[recordId];

        items.add(ScheduledDoseItem(
          medicine: med,
          time: time,
          date: dateKey,
          record: record,
        ));
      }
    }

    // Sort by scheduled time
    items.sort((a, b) => a.time.compareTo(b.time));
    return items;
  }

  AdherenceStats getAdherenceForDate(DateTime date) {
    final doses = getDosesForDate(date);
    int taken = 0;
    int skipped = 0;
    int pending = 0;

    for (final d in doses) {
      if (d.status == DoseStatus.taken) {
        taken++;
      } else if (d.status == DoseStatus.skipped) {
        skipped++;
      } else {
        pending++;
      }
    }

    return AdherenceStats(
      total: doses.length,
      taken: taken,
      skipped: skipped,
      pending: pending,
    );
  }

  /// Finds any doses that are due now, overdue, or whose snooze period has expired
  List<ScheduledDoseItem> getDueDosesNow() {
    final now = DateTime.now();
    final todayDoses = getDosesForDate(now);
    final results = <ScheduledDoseItem>[];

    for (final item in todayDoses) {
      final isSnoozeExpired = item.status == DoseStatus.snoozed &&
          item.record?.snoozedUntil != null &&
          item.record!.snoozedUntil!.isBefore(now);

      if (item.status == DoseStatus.pending || isSnoozeExpired) {
        final diff = item.scheduledDateTime.difference(now).inMinutes;
        // Due if overdue by up to 2 hours, or due within next 30 minutes, or snooze expired
        if (isSnoozeExpired || (diff >= -120 && diff <= 30)) {
          results.add(item);
        }
      }
    }
    return results;
  }

  Future<void> markDoseTaken({
    required String medicineId,
    required String date,
    required String time,
  }) async {
    final id = DoseRecord.generateId(medicineId, date, time);
    final updated = DoseRecord(
      id: id,
      medicineId: medicineId,
      date: date,
      time: time,
      status: DoseStatus.taken,
      takenAt: DateTime.now(),
    );

    _doseRecords[id] = updated;

    // Decrement stock if present
    final medIndex = _medicines.indexWhere((m) => m.id == medicineId);
    if (medIndex != -1) {
      final med = _medicines[medIndex];
      if (med.stockCount != null && med.stockCount! > 0) {
        _medicines[medIndex] = med.copyWith(stockCount: med.stockCount! - 1);
        await _storageService.saveMedicines(_medicines);
      }
    }

    await _storageService.saveDoseRecords(_doseRecords.values.toList());
    notifyListeners();
  }

  Future<void> markDoseSkipped({
    required String medicineId,
    required String date,
    required String time,
  }) async {
    final id = DoseRecord.generateId(medicineId, date, time);
    final updated = DoseRecord(
      id: id,
      medicineId: medicineId,
      date: date,
      time: time,
      status: DoseStatus.skipped,
    );

    _doseRecords[id] = updated;
    await _storageService.saveDoseRecords(_doseRecords.values.toList());
    notifyListeners();
  }

  Future<void> snoozeDose({
    required String medicineId,
    required String date,
    required String time,
    int minutes = 10,
  }) async {
    final id = DoseRecord.generateId(medicineId, date, time);
    final snoozedUntil = DateTime.now().add(Duration(minutes: minutes));

    final updated = DoseRecord(
      id: id,
      medicineId: medicineId,
      date: date,
      time: time,
      status: DoseStatus.snoozed,
      snoozedUntil: snoozedUntil,
    );

    _doseRecords[id] = updated;

    final med = getMedicineById(medicineId);
    if (med != null) {
      notificationService.snoozeNotification(
        medicine: med,
        reminderTime: time,
        minutes: minutes,
      );
    }

    await _storageService.saveDoseRecords(_doseRecords.values.toList());
    notifyListeners();
  }

  Future<void> resetDoseStatus({
    required String medicineId,
    required String date,
    required String time,
  }) async {
    final id = DoseRecord.generateId(medicineId, date, time);
    final previous = _doseRecords[id];

    // If reverting from taken, restore stock
    if (previous?.status == DoseStatus.taken) {
      final medIndex = _medicines.indexWhere((m) => m.id == medicineId);
      if (medIndex != -1) {
        final med = _medicines[medIndex];
        if (med.stockCount != null) {
          _medicines[medIndex] = med.copyWith(stockCount: med.stockCount! + 1);
          await _storageService.saveMedicines(_medicines);
        }
      }
    }

    _doseRecords.remove(id);
    await _storageService.saveDoseRecords(_doseRecords.values.toList());
    notifyListeners();
  }

  /// Pauses or resumes an existing schedule.
  /// When stopped/paused, pending notifications are cancelled.
  Future<void> toggleMedicineActive(String medicineId) async {
    final index = _medicines.indexWhere((m) => m.id == medicineId);
    if (index != -1) {
      final current = _medicines[index];
      final updated = current.copyWith(isActive: !current.isActive);
      _medicines[index] = updated;
      await _storageService.saveMedicines(_medicines);

      if (updated.isActive) {
        notificationService.scheduleForMedicine(updated);
      } else {
        notificationService.cancelForMedicine(medicineId);
      }
      notifyListeners();
    }
  }

  Future<void> addMedicine(Medicine medicine) async {
    _medicines.add(medicine);
    await _storageService.saveMedicines(_medicines);
    if (medicine.isActive) {
      notificationService.scheduleForMedicine(medicine);
    }
    notifyListeners();
  }

  Future<void> updateMedicine(Medicine medicine) async {
    final index = _medicines.indexWhere((m) => m.id == medicine.id);
    if (index != -1) {
      _medicines[index] = medicine;
      await _storageService.saveMedicines(_medicines);
      notificationService.updateForMedicine(medicine);
      notifyListeners();
    }
  }

  Future<void> deleteMedicine(String id) async {
    _medicines.removeWhere((m) => m.id == id);
    _doseRecords.removeWhere((key, record) => record.medicineId == id);
    notificationService.cancelForMedicine(id);
    await _storageService.saveMedicines(_medicines);
    await _storageService.saveDoseRecords(_doseRecords.values.toList());
    notifyListeners();
  }

  Medicine? getMedicineById(String id) {
    try {
      return _medicines.firstWhere((m) => m.id == id);
    } catch (_) {
      return null;
    }
  }
}
