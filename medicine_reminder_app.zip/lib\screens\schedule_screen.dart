import 'package:flutter/material.dart';
import '../providers/medicine_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/date_selector_strip.dart';
import '../widgets/adherence_summary_card.dart';
import '../widgets/dose_card.dart';
import '../widgets/reminder_banner.dart';
import 'medicine_detail_screen.dart';

class ScheduleScreen extends StatelessWidget {
  final MedicineController controller;

  const ScheduleScreen({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final selectedDate = controller.selectedDate;
    final doses = controller.getDosesForDate(selectedDate);
    final stats = controller.getAdherenceForDate(selectedDate);
    final dueDoses = controller.getDueDosesNow();

    // Group doses by time slot
    final morningDoses = doses.where((d) => d.timeSlot == 'Morning').toList();
    final afternoonDoses = doses.where((d) => d.timeSlot == 'Afternoon').toList();
    final eveningDoses = doses.where((d) => d.timeSlot == 'Evening').toList();
    final nightDoses = doses.where((d) => d.timeSlot == 'Night').toList();

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              controller.currentUser != null
                  ? 'Hi, ${controller.currentUser!.name.split(' ').first}'
                  : 'Daily Schedule',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 22),
            ),
            const Text(
              'Track your medicines & daily doses',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.normal, color: AppColors.lightSubtext),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Go to Today',
            icon: const Icon(Icons.today_rounded),
            onPressed: () => controller.selectDate(DateTime.now()),
          ),
          IconButton(
            tooltip: 'Account Profile',
            icon: CircleAvatar(
              radius: 15,
              backgroundColor: AppColors.primaryLight,
              child: Text(
                controller.currentUser?.name.isNotEmpty == true
                    ? controller.currentUser!.name[0].toUpperCase()
                    : 'U',
                style: const TextStyle(
                  color: AppColors.primaryDark,
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                ),
              ),
            ),
            onPressed: () => _showProfileDialog(context),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () => controller.loadData(),
        child: ListView(
          padding: const EdgeInsets.only(bottom: 80),
          children: [
            // Date Selector Strip
            DateSelectorStrip(
              selectedDate: selectedDate,
              onDateSelected: controller.selectDate,
            ),

            const SizedBox(height: 8),

            // Due doses reminder banner
            ReminderBanner(
              dueDoses: dueDoses,
              onTake: (item) async {
                await controller.markDoseTaken(
                  medicineId: item.medicine.id,
                  date: item.date,
                  time: item.time,
                );
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Marked ${item.medicine.name} as taken!'),
                      behavior: SnackBarBehavior.floating,
                      backgroundColor: AppColors.taken,
                    ),
                  );
                }
              },
              onSnooze: (item) async {
                await controller.snoozeDose(
                  medicineId: item.medicine.id,
                  date: item.date,
                  time: item.time,
                  minutes: 10,
                );
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Snoozed ${item.medicine.name} for 10 minutes'),
                      behavior: SnackBarBehavior.floating,
                      backgroundColor: const Color(0xFF7C3AED),
                    ),
                  );
                }
              },
            ),

            // Adherence Progress Card
            AdherenceSummaryCard(
              stats: stats,
              selectedDate: selectedDate,
            ),

            const SizedBox(height: 12),

            if (doses.isEmpty)
              _buildEmptyState(context, isDark)
            else ...[
              if (morningDoses.isNotEmpty)
                _buildSectionHeader(context, 'Morning', Icons.wb_sunny_outlined, const Color(0xFFF59E0B)),
              ...morningDoses.map((item) => _buildDoseItem(context, item)),

              if (afternoonDoses.isNotEmpty)
                _buildSectionHeader(context, 'Afternoon', Icons.wb_twilight_rounded, const Color(0xFFEA580C)),
              ...afternoonDoses.map((item) => _buildDoseItem(context, item)),

              if (eveningDoses.isNotEmpty)
                _buildSectionHeader(context, 'Evening', Icons.nights_stay_outlined, const Color(0xFF6366F1)),
              ...eveningDoses.map((item) => _buildDoseItem(context, item)),

              if (nightDoses.isNotEmpty)
                _buildSectionHeader(context, 'Night', Icons.bedtime_outlined, const Color(0xFF3B82F6)),
              ...nightDoses.map((item) => _buildDoseItem(context, item)),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(BuildContext context, String title, IconData icon, Color color) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 6),
      child: Row(
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(width: 8),
          Text(
            title,
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.3,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDoseItem(BuildContext context, ScheduledDoseItem item) {
    return DoseCard(
      item: item,
      onTake: () async {
        await controller.markDoseTaken(
          medicineId: item.medicine.id,
          date: item.date,
          time: item.time,
        );
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Marked ${item.medicine.name} as taken!'),
              behavior: SnackBarBehavior.floating,
              backgroundColor: AppColors.taken,
              duration: const Duration(seconds: 2),
            ),
          );
        }
      },
      onSkip: () async {
        await controller.markDoseSkipped(
          medicineId: item.medicine.id,
          date: item.date,
          time: item.time,
        );
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Skipped dose for ${item.medicine.name}'),
              behavior: SnackBarBehavior.floating,
              duration: const Duration(seconds: 2),
            ),
          );
        }
      },
      onSnooze: () async {
        await controller.snoozeDose(
          medicineId: item.medicine.id,
          date: item.date,
          time: item.time,
          minutes: 10,
        );
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Snoozed ${item.medicine.name} for 10 minutes'),
              behavior: SnackBarBehavior.floating,
              backgroundColor: const Color(0xFF7C3AED),
              duration: const Duration(seconds: 2),
            ),
          );
        }
      },
      onUndo: () async {
        await controller.resetDoseStatus(
          medicineId: item.medicine.id,
          date: item.date,
          time: item.time,
        );
      },
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => MedicineDetailScreen(
              medicineId: item.medicine.id,
              controller: controller,
            ),
          ),
        );
      },
    );
  }

  Widget _buildEmptyState(BuildContext context, bool isDark) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 48),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: isDark ? AppColors.darkCard : Colors.white,
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.check_circle_outline_rounded,
              size: 56,
              color: AppColors.primary,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'No Doses Scheduled',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: isDark ? AppColors.darkText : AppColors.lightText,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'You do not have any medications configured for this date.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              color: isDark ? AppColors.darkSubtext : AppColors.lightSubtext,
            ),
          ),
        ],
      ),
    );
  }

  void _showProfileDialog(BuildContext context) {
    final user = controller.currentUser;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(
          children: [
            Icon(Icons.account_circle_outlined, color: AppColors.primary),
            SizedBox(width: 8),
            Text('Account Profile'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircleAvatar(
              radius: 30,
              backgroundColor: AppColors.primaryLight,
              child: Text(
                user?.name.isNotEmpty == true ? user!.name[0].toUpperCase() : 'U',
                style: const TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  color: AppColors.primaryDark,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              user?.name ?? 'User',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Text(
              user?.email ?? '',
              style: const TextStyle(fontSize: 13, color: AppColors.lightSubtext),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Close'),
          ),
          FilledButton.icon(
            onPressed: () async {
              Navigator.of(ctx).pop();
              await controller.logout();
            },
            icon: const Icon(Icons.logout, size: 16),
            label: const Text('Sign Out'),
            style: FilledButton.styleFrom(backgroundColor: AppColors.overdue),
          ),
        ],
      ),
    );
  }
}
