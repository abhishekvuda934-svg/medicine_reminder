import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:medicine_reminder_app/main.dart';
import 'package:medicine_reminder_app/services/storage_service.dart';
import 'package:medicine_reminder_app/providers/medicine_controller.dart';

void main() {
  testWidgets('App displays LoginScreen initially, supports Quick Demo Login and Logout', (WidgetTester tester) async {
    SharedPreferences.setMockInitialValues({});
    final storageService = await StorageService.init();
    final controller = MedicineController(storageService);
    await controller.loadData();

    await tester.pumpWidget(MedicineReminderApp(controller: controller));
    await tester.pumpAndSettle();

    // Verify initial LoginScreen
    expect(find.text('Medicine Reminder'), findsOneWidget);
    expect(find.text('Sign In'), findsWidgets);
    expect(find.text('Quick Demo Login'), findsOneWidget);

    // Tap Quick Demo Login
    await tester.tap(find.text('Quick Demo Login'));
    await tester.pumpAndSettle();

    // Verify navigation to HomeScreen
    expect(find.text('Hi, Alex'), findsOneWidget);
    expect(find.widgetWithText(NavigationDestination, 'Today'), findsOneWidget);
    expect(find.widgetWithText(NavigationDestination, 'Medicines'), findsOneWidget);
    expect(find.widgetWithText(NavigationDestination, 'Adherence'), findsOneWidget);

    // Navigate to 'Medicines' catalog tab
    await tester.tap(find.widgetWithText(NavigationDestination, 'Medicines'));
    await tester.pumpAndSettle();

    expect(find.text('My Medicines'), findsOneWidget);
    expect(find.byType(FloatingActionButton), findsOneWidget);

    // Open profile dialog & Logout
    await tester.tap(find.widgetWithText(NavigationDestination, 'Today'));
    await tester.pumpAndSettle();

    final profileAvatar = find.byTooltip('Account Profile');
    expect(profileAvatar, findsOneWidget);
    await tester.tap(profileAvatar);
    await tester.pumpAndSettle();

    expect(find.text('Account Profile'), findsOneWidget);
    expect(find.text('Alex Johnson'), findsOneWidget);
    expect(find.text('demo@health.com'), findsOneWidget);

    // Tap Sign Out
    await tester.tap(find.text('Sign Out'));
    await tester.pumpAndSettle();

    // Verify back on LoginScreen
    expect(find.text('Quick Demo Login'), findsOneWidget);
  });
}
