enum DoseStatus {
  pending,
  taken,
  snoozed,
  skipped;

  String get displayName {
    switch (this) {
      case DoseStatus.pending:
        return 'Pending';
      case DoseStatus.taken:
        return 'Taken';
      case DoseStatus.snoozed:
        return 'Snoozed';
      case DoseStatus.skipped:
        return 'Skipped';
    }
  }
}

class DoseRecord {
  final String id; // key: "${medicineId}_${date}_${time}"
  final String medicineId;
  final String date; // "YYYY-MM-DD"
  final String time; // "HH:mm"
  final DoseStatus status;
  final DateTime? takenAt;
  final DateTime? snoozedUntil;
  final String? note;

  DoseRecord({
    required this.id,
    required this.medicineId,
    required this.date,
    required this.time,
    required this.status,
    this.takenAt,
    this.snoozedUntil,
    this.note,
  });

  static String generateId(String medicineId, String date, String time) {
    return '${medicineId}_${date}_$time';
  }

  DoseRecord copyWith({
    String? id,
    String? medicineId,
    String? date,
    String? time,
    DoseStatus? status,
    DateTime? takenAt,
    DateTime? snoozedUntil,
    String? note,
  }) {
    return DoseRecord(
      id: id ?? this.id,
      medicineId: medicineId ?? this.medicineId,
      date: date ?? this.date,
      time: time ?? this.time,
      status: status ?? this.status,
      takenAt: takenAt ?? this.takenAt,
      snoozedUntil: snoozedUntil ?? this.snoozedUntil,
      note: note ?? this.note,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'medicineId': medicineId,
      'date': date,
      'time': time,
      'status': status.name,
      'takenAt': takenAt?.toIso8601String(),
      'snoozedUntil': snoozedUntil?.toIso8601String(),
      'note': note,
    };
  }

  factory DoseRecord.fromJson(Map<String, dynamic> json) {
    return DoseRecord(
      id: json['id'] as String,
      medicineId: json['medicineId'] as String,
      date: json['date'] as String,
      time: json['time'] as String,
      status: DoseStatus.values.firstWhere(
        (e) => e.name == json['status'],
        orElse: () => DoseStatus.pending,
      ),
      takenAt: json['takenAt'] != null ? DateTime.parse(json['takenAt'] as String) : null,
      snoozedUntil: json['snoozedUntil'] != null ? DateTime.parse(json['snoozedUntil'] as String) : null,
      note: json['note'] as String?,
    );
  }
}
