import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/dose_record.dart';
import '../providers/medicine_controller.dart';
import '../theme/app_theme.dart';

class DoseCard extends StatelessWidget {
  final ScheduledDoseItem item;
  final VoidCallback onTake;
  final VoidCallback onSkip;
  final VoidCallback onUndo;
  final VoidCallback? onSnooze;
  final VoidCallback? onTap;

  const DoseCard({
    super.key,
    required this.item,
    required this.onTake,
    required this.onSkip,
    required this.onUndo,
    this.onSnooze,
    this.onTap,
  });

  String _formatTime12Hour(String time24) {
    try {
      final parts = time24.split(':');
      final hour = int.parse(parts[0]);
      final minute = int.parse(parts[1]);
      final dt = DateTime(2026, 1, 1, hour, minute);
      return DateFormat('h:mm a').format(dt);
    } catch (_) {
      return time24;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final med = item.medicine;
    final status = item.status;
    final isTaken = status == DoseStatus.taken;
    final isSkipped = status == DoseStatus.skipped;
    final isSnoozed = status == DoseStatus.snoozed;
    final isOverdue = item.isOverdue;

    Color statusColor;
    Color statusBgColor;
    String statusText;
    IconData statusIcon;

    if (isTaken) {
      statusColor = AppColors.taken;
      statusBgColor = isDark ? const Color(0xFF064E3B) : AppColors.takenLight;
      statusIcon = Icons.check_circle_rounded;
      if (item.record?.takenAt != null) {
        statusText = 'Taken at ${DateFormat('h:mm a').format(item.record!.takenAt!)}';
      } else {
        statusText = 'Taken';
      }
    } else if (isSkipped) {
      statusColor = AppColors.skipped;
      statusBgColor = isDark ? const Color(0xFF334155) : AppColors.skippedLight;
      statusIcon = Icons.cancel_outlined;
      statusText = 'Skipped';
    } else if (isSnoozed) {
      statusColor = const Color(0xFF7C3AED); // Purple
      statusBgColor = isDark ? const Color(0xFF3B0764) : const Color(0xFFEDE9FE);
      statusIcon = Icons.snooze_rounded;
      if (item.record?.snoozedUntil != null) {
        statusText = 'Snoozed until ${DateFormat('h:mm a').format(item.record!.snoozedUntil!)}';
      } else {
        statusText = 'Snoozed';
      }
    } else if (isOverdue) {
      statusColor = AppColors.overdue;
      statusBgColor = isDark ? const Color(0xFF7F1D1D) : AppColors.overdueLight;
      statusIcon = Icons.warning_amber_rounded;
      statusText = 'Overdue';
    } else {
      statusColor = AppColors.pending;
      statusBgColor = isDark ? const Color(0xFF78350F) : AppColors.pendingLight;
      statusIcon = Icons.schedule_rounded;
      statusText = 'Pending';
    }

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Icon Avatar
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: med.color.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: med.color.withValues(alpha: 0.4),
                        width: 1.5,
                      ),
                    ),
                    child: Icon(
                      med.type.icon,
                      color: med.color,
                      size: 26,
                    ),
                  ),
                  const SizedBox(width: 14),

                  // Med Name & Dosage
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                med.name,
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  decoration: isTaken ? TextDecoration.lineThrough : null,
                                  color: isTaken
                                      ? (isDark ? AppColors.darkSubtext : AppColors.lightSubtext)
                                      : (isDark ? AppColors.darkText : AppColors.lightText),
                                ),
                              ),
                            ),
                            // Scheduled Time Badge
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: isDark ? const Color(0xFF334155) : const Color(0xFFF1F5F9),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    Icons.access_time,
                                    size: 13,
                                    color: isDark ? AppColors.darkSubtext : AppColors.lightSubtext,
                                  ),
                                  const SizedBox(width: 4),
                                  Text(
                                    _formatTime12Hour(item.time),
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600,
                                      color: isDark ? AppColors.darkSubtext : AppColors.lightSubtext,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${med.dosage} • ${med.type.displayName}',
                          style: TextStyle(
                            fontSize: 13,
                            color: isDark ? AppColors.darkSubtext : AppColors.lightSubtext,
                          ),
                        ),
                        const SizedBox(height: 8),

                        // Tags row (Meal instruction, Schedule frequency, Status badge)
                        Wrap(
                          spacing: 6,
                          runSpacing: 4,
                          crossAxisAlignment: WrapCrossAlignment.center,
                          children: [
                            // Meal chip
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: isDark ? Colors.white10 : const Color(0xFFF1F5F9),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    med.instruction.icon,
                                    size: 12,
                                    color: isDark ? AppColors.darkSubtext : AppColors.lightSubtext,
                                  ),
                                  const SizedBox(width: 4),
                                  Text(
                                    med.instruction.displayName,
                                    style: TextStyle(
                                      fontSize: 11,
                                      color: isDark ? AppColors.darkSubtext : AppColors.lightSubtext,
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            // Schedule Frequency chip
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: isDark ? Colors.white10 : const Color(0xFFF1F5F9),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    med.scheduleType.icon,
                                    size: 12,
                                    color: isDark ? AppColors.darkSubtext : AppColors.lightSubtext,
                                  ),
                                  const SizedBox(width: 4),
                                  Text(
                                    med.scheduleDescription,
                                    style: TextStyle(
                                      fontSize: 11,
                                      color: isDark ? AppColors.darkSubtext : AppColors.lightSubtext,
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            // Status badge
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: statusBgColor,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(statusIcon, size: 12, color: statusColor),
                                  const SizedBox(width: 4),
                                  Text(
                                    statusText,
                                    style: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                      color: statusColor,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              const Divider(height: 1),
              const SizedBox(height: 8),

              // Action buttons row (Taken, Snooze, Skipped, Undo)
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  if (isTaken || isSkipped) ...[
                    TextButton.icon(
                      onPressed: onUndo,
                      icon: const Icon(Icons.undo_rounded, size: 16),
                      label: const Text('Undo', style: TextStyle(fontSize: 13)),
                      style: TextButton.styleFrom(
                        foregroundColor: isDark ? AppColors.darkSubtext : AppColors.lightSubtext,
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      ),
                    ),
                  ] else ...[
                    TextButton.icon(
                      onPressed: onSkip,
                      icon: const Icon(Icons.skip_next_rounded, size: 16),
                      label: const Text('Skip', style: TextStyle(fontSize: 13)),
                      style: TextButton.styleFrom(
                        foregroundColor: isDark ? AppColors.darkSubtext : AppColors.lightSubtext,
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      ),
                    ),
                    if (onSnooze != null) ...[
                      const SizedBox(width: 6),
                      OutlinedButton.icon(
                        onPressed: onSnooze,
                        icon: const Icon(Icons.snooze_rounded, size: 16, color: Color(0xFF7C3AED)),
                        label: const Text('Snooze (10m)', style: TextStyle(fontSize: 12, color: Color(0xFF7C3AED))),
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          side: const BorderSide(color: Color(0xFFDDD6FE)),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                    ],
                    const SizedBox(width: 8),
                    FilledButton.icon(
                      onPressed: onTake,
                      icon: const Icon(Icons.check_rounded, size: 18),
                      label: const Text('Take Dose', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                      style: FilledButton.styleFrom(
                        backgroundColor: isOverdue ? AppColors.overdue : AppColors.primary,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
