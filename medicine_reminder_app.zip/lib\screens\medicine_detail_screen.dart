import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../providers/medicine_controller.dart';
import '../theme/app_theme.dart';
import 'add_edit_medicine_screen.dart';

class MedicineDetailScreen extends StatelessWidget {
  final String medicineId;
  final MedicineController controller;

  const MedicineDetailScreen({
    super.key,
    required this.medicineId,
    required this.controller,
  });

  String _formatTime12Hour(String time24) {
    try {
      final parts = time24.split(':');
      final hour = int.parse(parts[0]);
      final minute = int.parse(parts[1]);
      final dt = DateTime(2026, 1, 1, hour, minute);
      return DateFormat('h:mm a').format(dt);
    } catch (_) {
      return time24;
    }
  }

  void _showTestNotificationDialog(BuildContext context, dynamic medicine) {
    final now = DateTime.now();
    final todayStr = MedicineController.formatDate(now);
    final firstTime = medicine.reminderTimes.isNotEmpty ? medicine.reminderTimes.first : '08:00';

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: medicine.color.withValues(alpha: 0.15),
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.notifications_active, color: medicine.color, size: 24),
            ),
            const SizedBox(width: 10),
            const Expanded(
              child: Text(
                'Local Notification',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Medicine: ${medicine.name}',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 6),
            Text(
              'Prescribed Dose: ${medicine.dosage}',
              style: const TextStyle(fontSize: 14),
            ),
            const SizedBox(height: 4),
            Text(
              'Reminder Time: ${_formatTime12Hour(firstTime)} (${medicine.instruction.displayName})',
              style: const TextStyle(fontSize: 13, color: AppColors.lightSubtext),
            ),
            const SizedBox(height: 16),
            const Divider(),
            const SizedBox(height: 8),
            const Text(
              'Choose action:',
              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () async {
              Navigator.of(ctx).pop();
              await controller.markDoseSkipped(
                medicineId: medicine.id,
                date: todayStr,
                time: firstTime,
              );
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Marked ${medicine.name} as Skipped'),
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              }
            },
            child: const Text('Skip', style: TextStyle(color: Colors.grey)),
          ),
          OutlinedButton.icon(
            onPressed: () async {
              Navigator.of(ctx).pop();
              await controller.snoozeDose(
                medicineId: medicine.id,
                date: todayStr,
                time: firstTime,
                minutes: 10,
              );
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Snoozed ${medicine.name} for 10 minutes'),
                    behavior: SnackBarBehavior.floating,
                    backgroundColor: const Color(0xFF7C3AED),
                  ),
                );
              }
            },
            icon: const Icon(Icons.snooze, size: 16, color: Color(0xFF7C3AED)),
            label: const Text('Snooze (10m)', style: TextStyle(color: Color(0xFF7C3AED))),
          ),
          FilledButton.icon(
            onPressed: () async {
              Navigator.of(ctx).pop();
              await controller.markDoseTaken(
                medicineId: medicine.id,
                date: todayStr,
                time: firstTime,
              );
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Marked ${medicine.name} as Taken!'),
                    backgroundColor: AppColors.taken,
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              }
            },
            icon: const Icon(Icons.check, size: 16),
            label: const Text('Taken'),
            style: FilledButton.styleFrom(backgroundColor: AppColors.taken),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final medicine = controller.getMedicineById(medicineId);

    if (medicine == null) {
      return Scaffold(
        appBar: AppBar(),
        body: const Center(child: Text('Medicine not found')),
      );
    }

    final pendingNotifications = controller.notificationService.getPendingForMedicine(medicine.id);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Medicine Details'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_outlined),
            tooltip: 'Edit Schedule',
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => AddEditMedicineScreen(
                    controller: controller,
                    medicineToEdit: medicine,
                  ),
                ),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline, color: Colors.red),
            tooltip: 'Delete Medicine',
            onPressed: () async {
              final confirmed = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text('Delete Medicine'),
                  content: Text('Are you sure you want to delete ${medicine.name} and cancel all its scheduled reminders?'),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.of(ctx).pop(false),
                      child: const Text('Cancel'),
                    ),
                    FilledButton(
                      onPressed: () => Navigator.of(ctx).pop(true),
                      style: FilledButton.styleFrom(backgroundColor: Colors.red),
                      child: const Text('Delete'),
                    ),
                  ],
                ),
              );

              if (confirmed == true && context.mounted) {
                await controller.deleteMedicine(medicine.id);
                if (context.mounted) {
                  Navigator.of(context).pop();
                }
              }
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // Header Card
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  medicine.color,
                  medicine.color.withValues(alpha: 0.8),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: medicine.color.withValues(alpha: 0.3),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Icon(
                    medicine.type.icon,
                    color: Colors.white,
                    size: 32,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        medicine.name,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${medicine.dosage} • ${medicine.type.displayName}',
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.9),
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),

          // Schedule Details Card
          const Text(
            'Schedule & Frequency',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(
                    children: [
                      Icon(medicine.scheduleType.icon, color: AppColors.primary, size: 20),
                      const SizedBox(width: 12),
                      const Text(
                        'Frequency:',
                        style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                      ),
                      const Spacer(),
                      Text(
                        medicine.scheduleDescription,
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                      ),
                    ],
                  ),
                  const Divider(height: 20),
                  Row(
                    children: [
                      const Icon(Icons.date_range, color: AppColors.primary, size: 20),
                      const SizedBox(width: 12),
                      const Text('Start Date:', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                      const Spacer(),
                      Text(DateFormat('MMM d, yyyy').format(medicine.startDate)),
                    ],
                  ),
                  const Divider(height: 20),
                  Row(
                    children: [
                      const Icon(Icons.event_available, color: AppColors.primary, size: 20),
                      const SizedBox(width: 12),
                      const Text('End Date:', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                      const Spacer(),
                      Text(medicine.endDate != null ? DateFormat('MMM d, yyyy').format(medicine.endDate!) : 'Ongoing'),
                    ],
                  ),
                  const Divider(height: 20),
                  Row(
                    children: [
                      Icon(
                        medicine.isActive ? Icons.check_circle_outline : Icons.pause_circle_outline,
                        color: medicine.isActive ? AppColors.taken : Colors.orange,
                        size: 20,
                      ),
                      const SizedBox(width: 12),
                      const Text('Schedule Status:', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                      const Spacer(),
                      Text(
                        medicine.isActive ? 'Active' : 'Paused / Stopped',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: medicine.isActive ? AppColors.taken : Colors.orange,
                        ),
                      ),
                    ],
                  ),
                  const Divider(height: 20),
                  Row(
                    children: [
                      const Icon(Icons.notifications_active_outlined, color: AppColors.primary, size: 20),
                      const SizedBox(width: 12),
                      const Text('Pending Notifications:', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                      const Spacer(),
                      Text(
                        '${pendingNotifications.length} scheduled',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),

          // Daily Reminder Times Section
          const Text(
            'Reminder Times',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: medicine.reminderTimes.map((time) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: medicine.color.withValues(alpha: 0.15),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(Icons.alarm, color: medicine.color, size: 20),
                        ),
                        const SizedBox(width: 14),
                        Text(
                          _formatTime12Hour(time),
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const Spacer(),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: isDark ? Colors.white10 : const Color(0xFFF1F5F9),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            medicine.instruction.displayName,
                            style: TextStyle(
                              fontSize: 12,
                              color: isDark ? AppColors.darkSubtext : AppColors.lightSubtext,
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ),
            ),
          ),

          const SizedBox(height: 20),

          // Instructions & Notes Card
          const Text(
            'Doctor Instructions & Notes',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(medicine.instruction.icon, color: AppColors.primary, size: 20),
                      const SizedBox(width: 10),
                      Text(
                        'Meal Timing: ${medicine.instruction.displayName}',
                        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                      ),
                    ],
                  ),
                  if (medicine.notes != null && medicine.notes!.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    const Divider(),
                    const SizedBox(height: 8),
                    const Text(
                      'Doctor Notes / Directions:',
                      style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppColors.lightSubtext),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      medicine.notes!,
                      style: const TextStyle(fontSize: 14, height: 1.4),
                    ),
                  ],
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),

          // Pause or Resume Schedule Button
          FilledButton.icon(
            onPressed: () async {
              await controller.toggleMedicineActive(medicine.id);
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(medicine.isActive
                        ? 'Paused schedule. All pending reminders have been cancelled.'
                        : 'Resumed schedule. Reminders have been scheduled.'),
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              }
            },
            icon: Icon(medicine.isActive ? Icons.pause_circle_outline : Icons.play_circle_outline),
            label: Text(
              medicine.isActive ? 'Stop / Pause Schedule' : 'Resume Schedule',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            style: FilledButton.styleFrom(
              backgroundColor: medicine.isActive ? Colors.orange : AppColors.primary,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),

          const SizedBox(height: 12),

          // Test Reminder Notification with Action buttons
          OutlinedButton.icon(
            onPressed: () => _showTestNotificationDialog(context, medicine),
            icon: const Icon(Icons.notifications_active_outlined),
            label: const Text('Test Notification & Actions (Taken / Snooze / Skip)'),
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}
