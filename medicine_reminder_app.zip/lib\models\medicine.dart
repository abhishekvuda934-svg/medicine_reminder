import 'package:flutter/material.dart';

enum MedicineType {
  tablet,
  capsule,
  syrup,
  injection,
  drops,
  inhaler,
  ointment;

  String get displayName {
    switch (this) {
      case MedicineType.tablet:
        return 'Tablet';
      case MedicineType.capsule:
        return 'Capsule';
      case MedicineType.syrup:
        return 'Syrup';
      case MedicineType.injection:
        return 'Injection';
      case MedicineType.drops:
        return 'Drops';
      case MedicineType.inhaler:
        return 'Inhaler';
      case MedicineType.ointment:
        return 'Ointment';
    }
  }

  IconData get icon {
    switch (this) {
      case MedicineType.tablet:
        return Icons.medication;
      case MedicineType.capsule:
        return Icons.healing;
      case MedicineType.syrup:
        return Icons.medication_liquid;
      case MedicineType.injection:
        return Icons.vaccines;
      case MedicineType.drops:
        return Icons.water_drop;
      case MedicineType.inhaler:
        return Icons.air;
      case MedicineType.ointment:
        return Icons.sanitizer;
    }
  }
}

enum MealInstruction {
  beforeMeal,
  afterMeal,
  withMeal,
  emptyStomach,
  anytime;

  String get displayName {
    switch (this) {
      case MealInstruction.beforeMeal:
        return 'Before meal';
      case MealInstruction.afterMeal:
        return 'After meal';
      case MealInstruction.withMeal:
        return 'With meal';
      case MealInstruction.emptyStomach:
        return 'Empty stomach';
      case MealInstruction.anytime:
        return 'Anytime';
    }
  }

  IconData get icon {
    switch (this) {
      case MealInstruction.beforeMeal:
        return Icons.restaurant_menu;
      case MealInstruction.afterMeal:
        return Icons.dinner_dining;
      case MealInstruction.withMeal:
        return Icons.lunch_dining;
      case MealInstruction.emptyStomach:
        return Icons.no_meals;
      case MealInstruction.anytime:
        return Icons.access_time;
    }
  }
}

enum ScheduleType {
  daily,
  weekly,
  monthly,
  customInterval;

  String get displayName {
    switch (this) {
      case ScheduleType.daily:
        return 'Daily';
      case ScheduleType.weekly:
        return 'Weekly';
      case ScheduleType.monthly:
        return 'Monthly';
      case ScheduleType.customInterval:
        return 'Custom Interval';
    }
  }

  IconData get icon {
    switch (this) {
      case ScheduleType.daily:
        return Icons.today;
      case ScheduleType.weekly:
        return Icons.view_week;
      case ScheduleType.monthly:
        return Icons.calendar_month;
      case ScheduleType.customInterval:
        return Icons.repeat;
    }
  }
}

class Medicine {
  final String id;
  final String name;
  final String dosage;
  final MedicineType type;
  final MealInstruction instruction;
  final List<String> reminderTimes; // "HH:mm" 24hr format
  final int colorValue;
  final DateTime startDate;
  final DateTime? endDate;
  final int? stockCount;
  final String? notes;
  final bool isActive;
  final ScheduleType scheduleType;
  final List<int> weeklyDays; // 1 = Monday, 7 = Sunday
  final int monthlyDay; // 1 to 31
  final int customIntervalDays; // e.g. every 2 or 3 days

  Medicine({
    required this.id,
    required this.name,
    required this.dosage,
    required this.type,
    required this.instruction,
    required this.reminderTimes,
    required this.colorValue,
    required this.startDate,
    this.endDate,
    this.stockCount,
    this.notes,
    this.isActive = true,
    this.scheduleType = ScheduleType.daily,
    this.weeklyDays = const [1, 2, 3, 4, 5, 6, 7],
    this.monthlyDay = 1,
    this.customIntervalDays = 1,
  });

  Color get color => Color(colorValue);

  String get scheduleDescription {
    switch (scheduleType) {
      case ScheduleType.daily:
        return 'Every day';
      case ScheduleType.weekly:
        if (weeklyDays.length == 7) return 'Every day';
        const dayNames = {
          1: 'Mon',
          2: 'Tue',
          3: 'Wed',
          4: 'Thu',
          5: 'Fri',
          6: 'Sat',
          7: 'Sun',
        };
        final sorted = List<int>.from(weeklyDays)..sort();
        return 'Weekly on ${sorted.map((d) => dayNames[d] ?? '').join(', ')}';
      case ScheduleType.monthly:
        final suffix = _getDayNumberSuffix(monthlyDay);
        return 'Monthly on $monthlyDay$suffix${monthlyDay >= 29 ? ' (or last day of month)' : ''}';
      case ScheduleType.customInterval:
        return 'Every $customIntervalDays day${customIntervalDays > 1 ? "s" : ""}';
    }
  }

  static String _getDayNumberSuffix(int day) {
    if (day >= 11 && day <= 13) return 'th';
    switch (day % 10) {
      case 1:
        return 'st';
      case 2:
        return 'nd';
      case 3:
        return 'rd';
      default:
        return 'th';
    }
  }

  /// Determines whether this medicine is scheduled on a given calendar date.
  /// Handles daily, weekly, monthly (with shorter month capping), and custom intervals.
  bool isScheduledOn(DateTime date) {
    if (!isActive) return false;

    final target = DateTime(date.year, date.month, date.day);
    final start = DateTime(startDate.year, startDate.month, startDate.day);
    if (target.isBefore(start)) return false;

    if (endDate != null) {
      final end = DateTime(endDate!.year, endDate!.month, endDate!.day);
      if (target.isAfter(end)) return false;
    }

    switch (scheduleType) {
      case ScheduleType.daily:
        return true;

      case ScheduleType.weekly:
        return weeklyDays.contains(target.weekday);

      case ScheduleType.monthly:
        // Handle months that do not contain the chosen day:
        // for example, if day 31 is chosen, in shorter months (e.g. Feb, Apr, Jun, Sep, Nov)
        // remind on the last day of that month.
        final daysInMonth = DateTime(target.year, target.month + 1, 0).day;
        final effectiveDay = monthlyDay > daysInMonth ? daysInMonth : monthlyDay;
        return target.day == effectiveDay;

      case ScheduleType.customInterval:
        if (customIntervalDays <= 0) return true;
        final diffDays = target.difference(start).inDays;
        return diffDays >= 0 && (diffDays % customIntervalDays == 0);
    }
  }

  Medicine copyWith({
    String? id,
    String? name,
    String? dosage,
    MedicineType? type,
    MealInstruction? instruction,
    List<String>? reminderTimes,
    int? colorValue,
    DateTime? startDate,
    DateTime? endDate,
    int? stockCount,
    String? notes,
    bool? isActive,
    ScheduleType? scheduleType,
    List<int>? weeklyDays,
    int? monthlyDay,
    int? customIntervalDays,
  }) {
    return Medicine(
      id: id ?? this.id,
      name: name ?? this.name,
      dosage: dosage ?? this.dosage,
      type: type ?? this.type,
      instruction: instruction ?? this.instruction,
      reminderTimes: reminderTimes ?? this.reminderTimes,
      colorValue: colorValue ?? this.colorValue,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      stockCount: stockCount ?? this.stockCount,
      notes: notes ?? this.notes,
      isActive: isActive ?? this.isActive,
      scheduleType: scheduleType ?? this.scheduleType,
      weeklyDays: weeklyDays ?? this.weeklyDays,
      monthlyDay: monthlyDay ?? this.monthlyDay,
      customIntervalDays: customIntervalDays ?? this.customIntervalDays,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'dosage': dosage,
      'type': type.name,
      'instruction': instruction.name,
      'reminderTimes': reminderTimes,
      'colorValue': colorValue,
      'startDate': startDate.toIso8601String(),
      'endDate': endDate?.toIso8601String(),
      'stockCount': stockCount,
      'notes': notes,
      'isActive': isActive,
      'scheduleType': scheduleType.name,
      'weeklyDays': weeklyDays,
      'monthlyDay': monthlyDay,
      'customIntervalDays': customIntervalDays,
    };
  }

  factory Medicine.fromJson(Map<String, dynamic> json) {
    return Medicine(
      id: json['id'] as String,
      name: json['name'] as String,
      dosage: json['dosage'] as String,
      type: MedicineType.values.firstWhere(
        (e) => e.name == json['type'],
        orElse: () => MedicineType.tablet,
      ),
      instruction: MealInstruction.values.firstWhere(
        (e) => e.name == json['instruction'],
        orElse: () => MealInstruction.afterMeal,
      ),
      reminderTimes: List<String>.from(json['reminderTimes'] as List),
      colorValue: json['colorValue'] as int? ?? 0xFF00897B,
      startDate: DateTime.parse(json['startDate'] as String),
      endDate: json['endDate'] != null ? DateTime.parse(json['endDate'] as String) : null,
      stockCount: json['stockCount'] as int?,
      notes: json['notes'] as String?,
      isActive: json['isActive'] as bool? ?? true,
      scheduleType: ScheduleType.values.firstWhere(
        (e) => e.name == json['scheduleType'],
        orElse: () => ScheduleType.daily,
      ),
      weeklyDays: json['weeklyDays'] != null
          ? List<int>.from(json['weeklyDays'] as List)
          : const [1, 2, 3, 4, 5, 6, 7],
      monthlyDay: json['monthlyDay'] as int? ?? 1,
      customIntervalDays: json['customIntervalDays'] as int? ?? 1,
    );
  }
}
