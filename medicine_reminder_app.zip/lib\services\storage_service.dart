import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/medicine.dart';
import '../models/dose_record.dart';
import '../models/app_user.dart';

class StorageService {
  static const String _keyMedicines = 'med_reminders_medicines_v1';
  static const String _keyDoseRecords = 'med_reminders_dose_records_v1';
  static const String _keyHasSeeded = 'med_reminders_has_seeded_v1';
  static const String _keyCurrentUser = 'med_reminders_current_user_v1';
  static const String _keyUsers = 'med_reminders_registered_users_v1';

  final SharedPreferences _prefs;

  StorageService(this._prefs);

  static Future<StorageService> init() async {
    final prefs = await SharedPreferences.getInstance();
    final service = StorageService(prefs);
    await service._seedSampleDataIfNeeded();
    return service;
  }

  Future<void> _seedSampleDataIfNeeded() async {
    final hasSeeded = _prefs.getBool(_keyHasSeeded) ?? false;
    if (!hasSeeded) {
      final now = DateTime.now();
      final todayStr = "${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}";

      // Default registered demo user
      final defaultUsers = {
        'demo@health.com': {
          'name': 'Alex Johnson',
          'email': 'demo@health.com',
          'password': 'password123',
        },
      };
      await _prefs.setString(_keyUsers, jsonEncode(defaultUsers));

      final sampleMedicines = [
        Medicine(
          id: 'med_amoxicillin',
          name: 'Amoxicillin',
          dosage: '500 mg',
          type: MedicineType.capsule,
          instruction: MealInstruction.afterMeal,
          reminderTimes: ['08:00', '20:00'],
          colorValue: 0xFF00897B, // Teal
          startDate: now.subtract(const Duration(days: 2)),
          endDate: now.add(const Duration(days: 5)),
          stockCount: 14,
          notes: 'Take with plenty of water. Finish complete course.',
        ),
        Medicine(
          id: 'med_vitamin_d',
          name: 'Vitamin D3',
          dosage: '1000 IU (1 tablet)',
          type: MedicineType.tablet,
          instruction: MealInstruction.withMeal,
          reminderTimes: ['09:30'],
          colorValue: 0xFFF57C00, // Amber / Orange
          startDate: now.subtract(const Duration(days: 10)),
          stockCount: 28,
          notes: 'Daily immunity supplement.',
        ),
        Medicine(
          id: 'med_metformin',
          name: 'Metformin',
          dosage: '500 mg',
          type: MedicineType.tablet,
          instruction: MealInstruction.withMeal,
          reminderTimes: ['13:00', '21:00'],
          colorValue: 0xFF3949AB, // Indigo
          startDate: now.subtract(const Duration(days: 30)),
          stockCount: 45,
          notes: 'Blood sugar control. Take right after lunch and dinner.',
        ),
        Medicine(
          id: 'med_cough_syrup',
          name: 'Guaifenesin Syrup',
          dosage: '10 ml',
          type: MedicineType.syrup,
          instruction: MealInstruction.beforeMeal,
          reminderTimes: ['22:00'],
          colorValue: 0xFFD81B60, // Rose / Pink
          startDate: now,
          endDate: now.add(const Duration(days: 3)),
          stockCount: 100,
          notes: 'Soothing night syrup for throat cough.',
        ),
      ];

      await saveMedicines(sampleMedicines);

      // Pre-mark morning dose for today as taken for demonstration
      final sampleRecords = [
        DoseRecord(
          id: DoseRecord.generateId('med_amoxicillin', todayStr, '08:00'),
          medicineId: 'med_amoxicillin',
          date: todayStr,
          time: '08:00',
          status: DoseStatus.taken,
          takenAt: now.subtract(const Duration(hours: 1)),
        ),
      ];
      await saveDoseRecords(sampleRecords);
      await _prefs.setBool(_keyHasSeeded, true);
    }
  }

  // Current logged in user session
  Future<AppUser?> loadCurrentUser() async {
    final raw = _prefs.getString(_keyCurrentUser);
    if (raw == null || raw.isEmpty) return null;
    try {
      final map = jsonDecode(raw) as Map<String, dynamic>;
      return AppUser.fromJson(map);
    } catch (_) {
      return null;
    }
  }

  Future<void> saveCurrentUser(AppUser? user) async {
    if (user == null) {
      await _prefs.remove(_keyCurrentUser);
    } else {
      await _prefs.setString(_keyCurrentUser, jsonEncode(user.toJson()));
    }
  }

  Future<void> clearCurrentUser() async {
    await _prefs.remove(_keyCurrentUser);
  }

  // Registered users map: email -> {'name': ..., 'email': ..., 'password': ...}
  Map<String, dynamic> _getRegisteredUsersMap() {
    final raw = _prefs.getString(_keyUsers);
    if (raw == null || raw.isEmpty) return {};
    try {
      return jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return {};
    }
  }

  Future<void> registerUser({
    required String name,
    required String email,
    required String password,
  }) async {
    final users = _getRegisteredUsersMap();
    users[email.toLowerCase().trim()] = {
      'name': name.trim(),
      'email': email.toLowerCase().trim(),
      'password': password,
    };
    await _prefs.setString(_keyUsers, jsonEncode(users));
  }

  bool isEmailRegistered(String email) {
    final users = _getRegisteredUsersMap();
    return users.containsKey(email.toLowerCase().trim());
  }

  AppUser? authenticate(String email, String password) {
    final users = _getRegisteredUsersMap();
    final cleanEmail = email.toLowerCase().trim();
    if (!users.containsKey(cleanEmail)) {
      // If demo user wasn't in storage yet, allow demo user
      if (cleanEmail == 'demo@health.com' && password == 'password123') {
        return AppUser(name: 'Alex Johnson', email: 'demo@health.com');
      }
      return null;
    }

    final userData = users[cleanEmail] as Map<String, dynamic>;
    if (userData['password'] == password) {
      return AppUser(
        name: userData['name'] as String? ?? 'User',
        email: cleanEmail,
      );
    }
    return null;
  }

  Future<List<Medicine>> loadMedicines() async {
    final jsonList = _prefs.getStringList(_keyMedicines);
    if (jsonList == null) return [];
    try {
      return jsonList
          .map((item) => Medicine.fromJson(jsonDecode(item) as Map<String, dynamic>))
          .toList();
    } catch (e) {
      return [];
    }
  }

  Future<void> saveMedicines(List<Medicine> medicines) async {
    final jsonList = medicines.map((m) => jsonEncode(m.toJson())).toList();
    await _prefs.setStringList(_keyMedicines, jsonList);
  }

  Future<List<DoseRecord>> loadDoseRecords() async {
    final jsonList = _prefs.getStringList(_keyDoseRecords);
    if (jsonList == null) return [];
    try {
      return jsonList
          .map((item) => DoseRecord.fromJson(jsonDecode(item) as Map<String, dynamic>))
          .toList();
    } catch (e) {
      return [];
    }
  }

  Future<void> saveDoseRecords(List<DoseRecord> records) async {
    final jsonList = records.map((r) => jsonEncode(r.toJson())).toList();
    await _prefs.setStringList(_keyDoseRecords, jsonList);
  }
}
