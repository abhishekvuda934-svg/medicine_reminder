class AppUser {
  final String name;
  final String email;

  AppUser({
    required this.name,
    required this.email,
  });

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'email': email,
    };
  }

  factory AppUser.fromJson(Map<String, dynamic> json) {
    return AppUser(
      name: json['name'] as String? ?? 'User',
      email: json['email'] as String? ?? '',
    );
  }
}
